using WebApplication1.Models;

namespace WebApplication1.Services
{
    public interface IEmailService
    {
        Task SendEmailAsync(EmailRequest request);
    }
}
