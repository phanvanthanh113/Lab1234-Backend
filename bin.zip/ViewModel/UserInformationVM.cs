namespace WebApplication1.ViewModel
{
    public class UserInformationVM
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Avatar { get; set; }
        public string? Region { get; set; }
    }
}
