namespace WebApplication1.DTO
{
    public class LoginRequest
    {
        public string? UserName { get; set; }
        public int OTP { get; set; }
    }
}
