namespace WebApplication1.DTO
{
    public class CheckOTPDTO
    {
        public string Email { get; set; }
        public int OTP { get; set; }
    }
}
